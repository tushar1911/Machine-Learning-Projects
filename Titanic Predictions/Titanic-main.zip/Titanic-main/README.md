This is the basic practicing projects on Kaggle Titanic dataset to predict the survival probability of the people based on certain characteristics.
This involves basic data visualization and data preprocessing followed by feature selection. 
We have tried multiple models to get better accuracy. 
